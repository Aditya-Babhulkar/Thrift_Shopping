package com.thriftshopping.webservice;

/**
 * Created by Anand Rawat on 02-04-2017.
 */

public class ServiceConstant {

    public static final String WALMART_ENDPOINT = "http://api.walmartlabs.com/v1/items?apiKey=";

    public static final String WALMART_API_KEY = "kgf35974z93mq9knncwprhkc";

    public static final String AMAZON_ACCESS_KEY_ID = "AKIAI73FTWLBDXMU5MNQ";

    public static final String AMAZON_SECRET_ACCESS_KEY = "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";

    public static final String AMAZON_ASSOCIATE_TAG = "thrifts0c-20";
}
