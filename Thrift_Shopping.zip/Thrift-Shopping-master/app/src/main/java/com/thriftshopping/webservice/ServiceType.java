package com.thriftshopping.webservice;

/**
 * Created by Anand Rawat on 02-04-2017.
 */

public enum ServiceType {
    AMAZON,
    WALMART
}
