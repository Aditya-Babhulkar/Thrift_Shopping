package com.thriftshopping.helper;

/**
 * Created by Adi on 4/25/2017.
 */

public enum FromActivityEnum {
    MAIN_ACTIVITY,
    WALMART_BAG,
    AMAZON_BAG
}
